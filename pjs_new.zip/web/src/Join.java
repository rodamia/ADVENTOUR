
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Join extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws IOException, ServletException{
		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String pw2 = request.getParameter("pw2");
		String name = request.getParameter("name");
		String nickname = request.getParameter("nickname");
		String postcode = request.getParameter("postcode");
		String addr1 = request.getParameter("addr1");
		String addr2 = request.getParameter("addr2");
		String email = request.getParameter("email");
		String email_domain = request.getParameter("email_domain");
		String pnum = request.getParameter("pnum");
		String how = request.getParameter("how");
		response.setContentType("text/html;charset=utf-8");
		
		PrintWriter out =response.getWriter();

		
		out.println("id : "+id+"<p>");
		out.println("pw : "+pw+"<p>");
		out.println("pw : "+pw2+"<p>");
		out.println("name : "+name+"<p>");
		out.println("nickname : "+nickname+"<p>");
		out.println("postcode : "+postcode+"<p>");
		out.println("addr : "+addr1+"<p>"+addr2+"<p>");
		out.println("email : "+email+"@"+email_domain+"<p>");
		out.println("pnum : "+pnum+"<p>");
		out.println("how : "+how+"<p>");
	}
}