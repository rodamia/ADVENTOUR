//
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//public class Dog extends HttpServlet
//{
//	public void doGet(HttpServletRequest request, HttpServletResponse response)
//	throws ServletException, IOException{
//		request.setCharacterEncoding("utf-8");
//		String[] ckb = request.getParameterValues("dog_check");
//		String[] img = request.getParameterValues("dog_img");
//		String[] select = new String[ckb.length + img.length];
//		int index = 0;
//		
//		response.setContentType("text/html;charset=utf-8");
//		
//		PrintWriter out =response.getWriter();
//		
//		out.println("<html>");
//		out.println("<head><title>Dog Img</title></head>");
//		out.println("<body>");
//		
//		
//
//		  for(String sel: ckb) {
//			  select[index++] = sel;
//		  }
//
//		  for(String sel: img) {
//			  select[index++] = sel;
//		  }
//
//		  System.out.println("ckb : " + Arrays.toString(ckb));
//		  System.out.println("img : " + Arrays.toString(img));
//		  System.out.println("newArray: " + Arrays.toString(newArray));
//		}
//		int index = 0;
//		for(int i=0; i<ckb.length; i++) {
//			for(int j=0; j<img.length; j++)
//				select= String[ckb][img];
//		}
//		if(ckb[0]) {
//			out.printf(img[0]);
//		}else if(ckb[1]) {
//			out.printf(img[1]);			
//		}else if(ckb[2]) {
//			out.printf(img[2]);			
//		}else if(ckb[3]) {
//			out.printf(img[3]);			
//			}
//		out.println("</body></html>");
//		}
//}
