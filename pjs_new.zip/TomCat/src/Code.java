

public class Code {

	private String code;
	
	public String getCode(){
		return code;
	}
	public void setName(String code) {
		this.code = code;
	}
}

