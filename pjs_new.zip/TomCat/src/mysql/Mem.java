package mysql;

import java.sql.Connection;
import java.sql.DriverManager;

import com.mysql.jdbc.Statement;

public class Mem {
	public  conn;
	public void name() {
				Connection conn = null; 
				Statement stmt = null;
				try{
				   Class.forName("com.mysql.jdbc.Driver"); /*�����׺��̽��� ����*/
				   conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/spthe?characterEncoding=utf8","root","dkssud2!!");
				   if(conn== null)
				      throw new Exception("�����ͺ��̽��� ������ �� �����ϴ�.");
				   stmt = conn.createStatement();
				   String command = String.format("select *from student(m_id, m_pw, m_lastname,  m_firstname, m_nickname,  m_postcode, m_addr1, m_addr2, m_pum1, m_pnum2, m_email, m_birth_y, m_birth_m, m_birth_d, m_gender, m_agree);");	
								  
				   
				    int rowNum = stmt.executeUpdate(command);
				   
				   if(rowNum < 1)
				      throw new Exception("�����͸� DB�� �Է��� �� �����ϴ�.");
				   
				} finally {
				   try {
				      stmt.close();
				   } catch (Exception ignored) {
				      
				   } try {
				      conn.close();
				   } catch (Exception ignored){
				      
				   } }
	}
	public static void main(String[] args) {

	}

}
