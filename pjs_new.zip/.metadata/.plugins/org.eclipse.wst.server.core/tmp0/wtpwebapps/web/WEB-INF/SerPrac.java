import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class SerPrac extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) //html에 method와 연결 되어 있다 - doPost도 가능 = 둘이 동일해야한다 
	throws IOException,ServletException{
		request.setCharacterEncoding("utf-8");
		String str1 = request.getParameter("NUM1");  //NUM1의 값을 str1에 담는다
		String str2 = request.getParameter("NUM2");  //NUM2의 값을 str2에 담는다
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();      //입력을 받아온다
		int num1 = Integer.parseInt(str1);  //str로 받아온 값을 정수형으로 변환해 정수형 객체에 담아서
		int num2 = Integer.parseInt(str2);
		int result = num1 + num2;  // 위 두 변수를 더한 값을 result 변수에 담는다
		
		out.println("<HTML>");     
		out.println("<HEAD><TITLE>더해더해</TITLE></HEAD>");
		out.println("<BODY>");
		out.printf("%d+%d=%d",num1,num2,result);
		out.println("</BODY>");
		out.println("</HTML>");
		
	}
}



